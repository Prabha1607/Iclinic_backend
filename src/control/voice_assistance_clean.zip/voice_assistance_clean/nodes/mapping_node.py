from src.control.voice_assistance.prompts.mapping_node_prompt import (
    CLASSIFIER_SYSTEM_PROMPT,
    DEFAULT_INTENT,
    EMERGENCY_RESPONSE,
    SYSTEM_PROMPT,
)
from src.control.voice_assistance.utils import (
    build_catalogue_lines,
    build_conversation_string,
    fallback_appointment_type_id,
    llm_extract_json,
    update_state,
)


def _normalise(text: str) -> str:
    return text.strip().lower().replace(" ", "_").replace("-", "_")


async def _resolve_appointment_type_id(intent: str, appointment_types: dict) -> int | None:
    prompt = (
        f"Given the following appointment type catalogue:\n"
        f"{build_catalogue_lines(appointment_types)}\n\n"
        f'The patient has been classified with intent: "{intent}"\n\n'
        f"Return ONLY a JSON object with the single key \"appointment_type_id\" containing the integer ID "
        f"that best matches the intent. If nothing matches, use the ID for general check-up.\n\n"
        f'Example: {{"appointment_type_id": 3}}'
    )
    try:
        parsed = await llm_extract_json(system=CLASSIFIER_SYSTEM_PROMPT, human=prompt)
        return int(parsed.get("appointment_type_id"))
    except Exception:
        return fallback_appointment_type_id(appointment_types)


async def _classify_intent(conversation_transcript: str, appointment_types: dict) -> str:
    prompt = (
        f"Appointment type catalogue:\n{build_catalogue_lines(appointment_types)}\n\n"
        f"Full intake conversation:\n{conversation_transcript}\n\n"
        f"Based on the full conversation above, classify the patient into the most appropriate appointment type.\n"
        f"Return JSON with key \"intent\" only."
    )
    try:
        parsed = await llm_extract_json(system=SYSTEM_PROMPT, human=prompt)
        intent = str(parsed.get("intent", DEFAULT_INTENT)).strip().lower()
    except Exception:
        return DEFAULT_INTENT

    valid_intents = [_normalise(name) for _, (name, _) in appointment_types.items()]
    return intent if intent in valid_intents else DEFAULT_INTENT


async def mapping_node(state: dict) -> dict:
    print("[mapping_node] -----------------------------")

    if state.get("mapping_emergency"):
        return update_state(
            state,
            mapping_intent="emergency",
            mapping_appointment_type_id=None,
            mapping_appointment_type_completed=True,
            speech_ai_text=EMERGENCY_RESPONSE,
        )

    appointment_types: dict    = state.get("appointment_types") or {}
    conversation_history: list = list(state.get("clarify_conversation_history") or [])
    conversation_transcript    = build_conversation_string(conversation_history)

    try:
        intent = (
            DEFAULT_INTENT
            if not conversation_transcript
            else await _classify_intent(conversation_transcript, appointment_types)
        )
        appointment_type_id = await _resolve_appointment_type_id(intent, appointment_types)
    except Exception:
        intent              = DEFAULT_INTENT
        appointment_type_id = fallback_appointment_type_id(appointment_types) if appointment_types else None

    friendly_name = intent.replace("_", " ").title()

    return update_state(
        state,
        mapping_intent=intent,
        mapping_appointment_type_id=appointment_type_id,
        appointment_types=appointment_types,
        mapping_appointment_type_completed=True,
        speech_ai_text=(
            f"Based on what you've described, I'll book a {friendly_name} appointment for you. "
            f"You'll receive a confirmation shortly."
        ),
    )
