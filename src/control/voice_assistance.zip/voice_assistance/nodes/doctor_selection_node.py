import asyncio
import json
from src.data.clients.postgres_client import AsyncSessionLocal
from src.data.repositories.generic_crud import bulk_get_instance
from src.data.models.postgres.user import User, ProviderProfile
from src.control.voice_assistance.models import astream_llm
from src.control.voice_assistance.utils import clear_markdown
from src.control.voice_assistance.prompts.doctor_selection_node_prompt import (
    NO_DOCTORS_RESPONSE,
    DOCTOR_CONVERSATION_PROMPT,
    DOCTOR_VERIFIER_PROMPT,
    DOCTOR_INTENT_VERIFIER_PROMPT,
)


async def _collect(messages: list) -> str:
    full_content = ""
    async for token in astream_llm(messages):
        full_content += token
    return full_content


async def fetch_doctors(appointment_type_id: int) -> list[dict]:
    async with AsyncSessionLocal() as db:
        users = await bulk_get_instance(User, db, role_id=2, is_active=True, appointment_type_id=appointment_type_id)
        doctor_ids = [u.id for u in users]
        all_profiles = await bulk_get_instance(ProviderProfile, db)
        profile_map = {p.user_id: p for p in all_profiles if p.user_id in doctor_ids}
        return [
            {
                "id": u.id,
                "name": f"Dr. {u.first_name} {u.last_name}",
                "specialization": profile_map[u.id].specialization if u.id in profile_map else "N/A",
                "qualification": profile_map[u.id].qualification if u.id in profile_map else "N/A",
                "experience": profile_map[u.id].experience if u.id in profile_map else 0,
                "bio": profile_map[u.id].bio if u.id in profile_map else "",
            }
            for u in users
        ]


def _doctors_context(doctors: list[dict]) -> str:
    return "\n".join(
        f"{i+1}. id={d['id']} name={d['name']} specialization={d['specialization']} "
        f"experience={d['experience']}yrs qualification={d['qualification']} bio={d['bio']}"
        for i, d in enumerate(doctors)
    )


async def _check_user_intent(user_text: str, doctors: list[dict]) -> str:
    try:
        full_content = ""
        async for token in astream_llm([
            {"role": "system", "content": DOCTOR_INTENT_VERIFIER_PROMPT},
            {"role": "user", "content": f"Doctors:\n{_doctors_context(doctors)}\n\nPatient said: {user_text}"},
        ]):
            full_content += token
        data = json.loads(clear_markdown(full_content.strip()))
        return data.get("intent", "unknown")
    except Exception as e:
        print("[doctor intent verifier error]:", e)
        return "unknown"


async def _verify_selection(user_text: str, doctors: list[dict]) -> tuple[int | None, str | None]:
    try:
        full_content = ""
        async for token in astream_llm([
            {"role": "system", "content": DOCTOR_VERIFIER_PROMPT},
            {"role": "user", "content": f"Doctors:\n{_doctors_context(doctors)}\n\nPatient said: {user_text}"},
        ]):
            full_content += token
        data = json.loads(clear_markdown(full_content.strip()))
        doctor_id = data.get("doctor_id")
        doctor_name = data.get("doctor_name")
        return (int(doctor_id), str(doctor_name)) if doctor_id else (None, None)
    except Exception as e:
        print("[doctor verifier error]:", e)
        return None, None


def _build_messages(
    mode: str,
    history: list[dict],
    doctors: list[dict],
    intent: str,
    previous_doctor: str | None,
    change_request: str | None,
    bridge_text: str | None = None,
) -> list[dict]:
    seed = history if history else [{"role": "user", "content": "start"}]
    return [
        {
            "role": "system",
            "content": DOCTOR_CONVERSATION_PROMPT.format(
                doctors_context=_doctors_context(doctors),
                intent=intent,
                mode=mode,
                previous_doctor=previous_doctor or "none",
                change_request=change_request or "none",
                bridge_text=bridge_text or "none",
            ),
        },
        *seed,
    ]


async def doctor_selection_node(state: dict) -> dict:
    print("[doctor_selection_node] -----------------------------")

    user_change_request: str | None = state.get("user_change_request")
    previous_doctor_name: str | None = state.get("doctor_confirmed_name")
    user_text: str = (state.get("speech_user_text") or "").strip()
    history: list[dict] = list(state.get("doctor_selection_history") or [])
    intent: str = state.get("mapping_intent") or "general checkup"

    # The bridge text spoken at end of clarify_node e.g.
    # "I'll go ahead and look into booking a General Checkup for you now."
    bridge_text: str | None = state.get("speech_ai_text") if not history else None

    is_first_entry = len(history) == 0

    try:
        doctors = await fetch_doctors(state.get("mapping_appointment_type_id") or -1)
    except Exception as e:
        print("[doctor_selection_node] fetch failed:", e)
        return {**state, "doctor_selection_completed": True, "speech_ai_text": NO_DOCTORS_RESPONSE}

    if not doctors:
        return {**state, "doctor_selection_completed": True, "speech_ai_text": NO_DOCTORS_RESPONSE}

    if user_change_request and previous_doctor_name:
        available_doctors = [d for d in doctors if d["name"] != previous_doctor_name] or doctors
    else:
        available_doctors = doctors

    # ── First entry: do NOT consume user_text (it belongs to clarify).
    # Instead use bridge_text as context and present doctors smoothly.
    if is_first_entry:
        if len(available_doctors) == 1:
            mode = "auto_select_fresh"
        else:
            mode = "present_options_fresh"

        messages = _build_messages(
            mode, history, available_doctors, intent,
            previous_doctor_name, user_change_request, bridge_text,
        )
        ai_text = (await _collect(messages)).strip().strip('"').strip("'")
        print("[ai_response (first entry)]:", ai_text)
        history.append({"role": "assistant", "content": ai_text})

        result = {
            **state,
            "doctor_selection_pending": len(available_doctors) > 1,
            "doctor_selection_completed": False,
            "doctor_list": available_doctors,
            "doctor_selection_history": history,
            "speech_ai_text": ai_text,
        }

        # Auto-select: mark confirmed immediately
        if len(available_doctors) == 1:
            doctor = available_doctors[0]
            result.update({
                "doctor_confirmed_id": doctor["id"],
                "doctor_confirmed_name": doctor["name"],
                "doctor_selection_pending": False,
                "doctor_selection_completed": True,
            })

        return result

    # ── Subsequent entries: normal user_text processing ──────────────────────
    if user_text:
        history.append({"role": "user", "content": user_text})

    # Already confirmed a doctor — handle follow-up questions or proceed
    if state.get("doctor_confirmed_id") and not user_change_request:
        if user_text:
            messages = _build_messages(
                "handle_question", history, doctors, intent,
                previous_doctor_name, user_change_request,
            )
            user_intent, full_content = await asyncio.gather(
                _check_user_intent(user_text, doctors),
                _collect(messages),
            )
            print("[user_intent]:", user_intent)

            if user_intent in ("asking_info", "change_request", "unclear"):
                ai_text = full_content.strip().strip('"').strip("'")
                history.append({"role": "assistant", "content": ai_text})
                return {
                    **state,
                    "doctor_selection_history": history,
                    "speech_ai_text": ai_text,
                    "doctor_selection_completed": False,
                }

        return {**state, "doctor_selection_completed": True}

    # Single doctor (change scenario)
    if len(available_doctors) == 1 and not user_change_request:
        doctor = available_doctors[0]
        messages = _build_messages(
            "auto_select", history, available_doctors, intent,
            previous_doctor_name, user_change_request,
        )
        ai_text = (await _collect(messages)).strip().strip('"').strip("'")
        history.append({"role": "assistant", "content": ai_text})
        return {
            **state,
            "user_change_request": None,
            "doctor_confirmed_id": doctor["id"],
            "doctor_confirmed_name": doctor["name"],
            "doctor_selection_pending": False,
            "doctor_selection_completed": True,
            "doctor_selection_history": history,
            "speech_ai_text": ai_text,
        }

    # Multiple doctors — patient is responding to options
    if user_text and state.get("doctor_selection_pending"):
        messages_asking  = _build_messages(
            "handle_question", history, available_doctors, intent,
            previous_doctor_name, user_change_request,
        )
        messages_confirm = _build_messages(
            "confirm_selection", history, available_doctors, intent,
            previous_doctor_name, user_change_request,
        )

        user_intent, content_asking, content_confirm, verify_result = await asyncio.gather(
            _check_user_intent(user_text, available_doctors),
            _collect(messages_asking),
            _collect(messages_confirm),
            _verify_selection(user_text, available_doctors),
        )
        print("[user_intent]:", user_intent)

        if user_intent == "asking_info":
            ai_text = content_asking.strip().strip('"').strip("'")
            history.append({"role": "assistant", "content": ai_text})
            return {
                **state,
                "doctor_selection_history": history,
                "doctor_selection_pending": True,
                "doctor_selection_completed": False,
                "speech_ai_text": ai_text,
            }

        if user_intent == "selecting":
            doctor_id, doctor_name = verify_result
            if doctor_id:
                ai_text = content_confirm.strip().strip('"').strip("'")
                history.append({"role": "assistant", "content": ai_text})
                return {
                    **state,
                    "user_change_request": None,
                    "doctor_confirmed_id": doctor_id,
                    "doctor_confirmed_name": doctor_name,
                    "doctor_selection_completed": True,
                    "doctor_selection_pending": False,
                    "doctor_selection_history": history,
                    "speech_ai_text": ai_text,
                }

    # Fallback: re-present options
    messages = _build_messages(
        "present_options", history, available_doctors, intent,
        previous_doctor_name, user_change_request,
    )
    ai_text = (await _collect(messages)).strip().strip('"').strip("'")
    print("[ai_response]:", ai_text)
    history.append({"role": "assistant", "content": ai_text})

    return {
        **state,
        "doctor_selection_pending": True,
        "doctor_selection_completed": False,
        "doctor_list": available_doctors,
        "doctor_selection_history": history,
        "speech_ai_text": ai_text,
    }

